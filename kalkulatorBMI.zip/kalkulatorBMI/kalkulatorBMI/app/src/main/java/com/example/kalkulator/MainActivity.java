package com.example.kalkulator;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextTezina, editTextVisina;
    private TextView textViewRezultat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTezina = findViewById(R.id.editTextTežina);
        editTextVisina = findViewById(R.id.editTextVisina);
        textViewRezultat = findViewById(R.id.textViewRezultat);
    }

    public void calculateBMI(View view) {
        String weightString = editTextTezina.getText().toString();
        String heightString = editTextVisina.getText().toString();

        if (!weightString.isEmpty() && !heightString.isEmpty()) {
            float weight = Float.parseFloat(weightString);
            float height = Float.parseFloat(heightString) / 100;
            
            float bmi = weight / (height * height);
            
            displayResult(bmi);
        } else {
            textViewRezultat.setText("Unesite težinu i visinu.");
        }
    }

    private void displayResult(float bmi) {
        String category;
        if (bmi < 18.5) {
            category = "Nedovoljna težina";
        } else if (bmi < 24.9) {
            category = "Normalna težina";
        } else if (bmi < 29.9) {
            category = "Prekomijerna težina";
        } else {
            category = "Pretilost";
        }
        
        String resultMessage = String.format("BMI: %.2f\nKategorija: %s", bmi, category);
        textViewRezultat.setText(resultMessage);
    }
}
